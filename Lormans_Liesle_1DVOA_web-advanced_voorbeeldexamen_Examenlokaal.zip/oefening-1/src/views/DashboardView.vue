<script setup>
import { ref } from 'vue';

const selectie = ref(null);
</script>

<template>
  <main>
    <h1>Dashboard</h1>

    <p v-if="selectie" class="melding">Je hebt {{ selectie }} geselecteerd.</p>

    <div class="kaarten">
      <div class="stat-kaart">
        <h2 class="stat-label">Actieve gebruikers</h2>
        <p class="stat-waarde">1284 <span class="stat-eenheid">gebruikers</span></p>
        <p>Gemeten over de afgelopen 30 dagen.</p>
      </div>

      <div class="stat-kaart">
        <h2 class="stat-label">Omzet deze maand</h2>
        <p class="stat-waarde">24600 <span class="stat-eenheid">euro</span></p>
        <p>Ten opzichte van vorige maand +12%.</p>
      </div>

      <div class="stat-kaart">
        <h2 class="stat-label">Openstaande tickets</h2>
        <p class="stat-waarde">37 <span class="stat-eenheid">tickets</span></p>
        <p>Waarvan 5 met hoge prioriteit.</p>
      </div>
    </div>
  </main>
</template>
