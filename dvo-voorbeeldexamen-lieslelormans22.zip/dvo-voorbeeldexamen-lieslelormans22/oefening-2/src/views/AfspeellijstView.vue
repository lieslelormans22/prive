<script setup>
import { computed } from 'vue';
import { useNummersStore } from '@/stores/nummers.js';
import { useAfspeellijstStore } from '@/stores/afspeellijst.js';
import NummerCard from '@/components/NummerCard.vue';

const nummersStore = useNummersStore();
const afspeellijstStore = useAfspeellijstStore();

const nummersInAfspeellijst = computed(() =>
  nummersStore.nummers.filter((nummer) =>
    afspeellijstStore.afspeellijst.includes(nummer.id)
  )
);
</script>

<template>
  <div>
    <h1>Afspeellijst</h1>

    <p v-if="nummersInAfspeellijst.length === 0">Je afspeellijst is leeg.</p>

    <div v-else class="nummers-lijst">
      <NummerCard
        v-for="nummer in nummersInAfspeellijst"
        :key="nummer.id"
        :titel="nummer.titel"
        :artiest="nummer.artiest"
        :inAfspeellijst="true"
        @toggleNummer="afspeellijstStore.toggleNummer(nummer.id)"
      >
        {{ nummer.beschrijving }}
      </NummerCard>
    </div>
  </div>
</template>

<style scoped>
.nummers-lijst {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 1rem;
}
</style>
