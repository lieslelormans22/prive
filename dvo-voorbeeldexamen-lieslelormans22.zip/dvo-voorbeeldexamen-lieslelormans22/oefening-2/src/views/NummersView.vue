<script setup>
import { onMounted } from 'vue';
import { useNummersStore } from '@/stores/nummers.js';
import { useAfspeellijstStore } from '@/stores/afspeellijst.js';
import NummerCard from '@/components/NummerCard.vue';

const nummersStore = useNummersStore();
const afspeellijstStore = useAfspeellijstStore();

onMounted(() => {
  nummersStore.fetchNummers();
});
</script>

<template>
  <div>
    <h1>Nummers</h1>

    <p v-if="nummersStore.loading">Laden...</p>

    <div v-else class="nummers-lijst">
      <NummerCard
        v-for="nummer in nummersStore.nummers"
        :key="nummer.id"
        :titel="nummer.titel"
        :artiest="nummer.artiest"
        :inAfspeellijst="afspeellijstStore.afspeellijst.includes(nummer.id)"
        @toggleNummer="afspeellijstStore.toggleNummer(nummer.id)"
      >
        {{ nummer.beschrijving }}
      </NummerCard>
    </div>
  </div>
</template>

<style scoped>
.nummers-lijst {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 1rem;
}
</style>
