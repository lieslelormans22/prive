<script setup>
defineProps({
  titel: {
    type: String,
    required: true,
  },
  artiest: {
    type: String,
    required: true,
  },
  inAfspeellijst: {
    type: Boolean,
    default: false,
  },
});

const emit = defineEmits(['toggleNummer']);
</script>

<template>
  <div class="nummer-card">
    <h2>{{ titel }}</h2>
    <p class="artiest">{{ artiest }}</p>
    <p class="beschrijving"><slot /></p>
    <button @click="emit('toggleNummer')">
      {{ inAfspeellijst ? 'Verwijder uit afspeellijst' : 'Voeg toe aan afspeellijst' }}
    </button>
  </div>
</template>

<style scoped>
.nummer-card {
  border: 2px solid #333;
  padding: 1rem;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

h2 {
  font-size: 1.1rem;
  font-weight: 700;
  margin: 0;
}

.artiest {
  font-style: italic;
  color: #555;
  margin: 0;
}

.beschrijving {
  font-size: 0.9rem;
  margin: 0;
}

button {
  margin-top: 0.5rem;
  padding: 0.4rem 0.8rem;
  cursor: pointer;
  border: 1px solid #333;
  background: #fff;
  font-size: 0.85rem;
  align-self: flex-start;
}

button:hover {
  background: #f0f0f0;
}
</style>
