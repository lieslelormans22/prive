export function fakeFetch(data) {
  const delay = Math.floor(Math.random() * 700) + 300;
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        ok: true,
        status: 200,
        json: () => Promise.resolve(data),
      });
    }, delay);
  });
}
