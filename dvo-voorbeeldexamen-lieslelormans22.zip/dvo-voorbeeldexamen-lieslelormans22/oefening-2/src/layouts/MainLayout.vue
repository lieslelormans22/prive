<script setup>
import { RouterLink, RouterView } from 'vue-router';
</script>

<template>
  <header>
    <h1>Muziekapp</h1>
    <nav>
      <RouterLink to="/nummers">Nummers</RouterLink>
      <RouterLink to="/afspeellijst">Afspeellijst</RouterLink>
    </nav>
  </header>

  <main>
    <RouterView />
  </main>
</template>

<style scoped>
header {
  display: flex;
  align-items: center;
  gap: 2rem;
  padding: 1rem 2rem;
  border-bottom: 2px solid #333;
  margin-bottom: 2rem;
}

h1 {
  margin: 0;
  font-size: 1.5rem;
}

nav {
  display: flex;
  gap: 1rem;
}

nav a {
  text-decoration: none;
  color: #333;
  font-weight: 600;
}

nav a.router-link-active {
  text-decoration: underline;
}
</style>
