import { createRouter, createWebHistory } from 'vue-router';
import MainLayout from '@/layouts/MainLayout.vue';
import NummersView from '@/views/NummersView.vue';

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      component: MainLayout,
      children: [
        {
          path: 'nummers',
          component: NummersView,
        },
        {
          path: 'afspeellijst',
          component: () => import('@/views/AfspeellijstView.vue'),
        },
      ],
    },
  ],
});

export default router;
