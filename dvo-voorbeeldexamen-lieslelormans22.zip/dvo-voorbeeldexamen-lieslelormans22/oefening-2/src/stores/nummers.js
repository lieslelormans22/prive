import { ref } from 'vue';
import { defineStore } from 'pinia';
import { fakeFetch } from '@/utils/fakeFetch.js';
import nummersData from '@/data/nummers.json';

export const useNummersStore = defineStore('nummers', () => {
  const nummers = ref([]);
  const loading = ref(false);

  async function fetchNummers() {
    loading.value = true;
    const response = await fakeFetch(nummersData);
    const data = await response.json();
    nummers.value = data.map((item) => ({
      id: item.id,
      titel: item.title,
      artiest: item.artist,
      beschrijving: item.body,
    }));
    loading.value = false;
  }

  return { nummers, loading, fetchNummers };
});
