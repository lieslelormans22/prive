import { ref, computed } from 'vue';
import { defineStore } from 'pinia';

export const useAfspeellijstStore = defineStore('afspeellijst', () => {
  const afspeellijst = ref([]);

  const aantalInAfspeellijst = computed(() => afspeellijst.value.length);

  function toggleNummer(id) {
    const index = afspeellijst.value.indexOf(id);
    if (index === -1) {
      afspeellijst.value.push(id);
    } else {
      afspeellijst.value.splice(index, 1);
    }
  }

  return { afspeellijst, aantalInAfspeellijst, toggleNummer };
});
