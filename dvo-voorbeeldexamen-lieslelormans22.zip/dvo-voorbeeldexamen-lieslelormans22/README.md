## Werkwijze

Wat je thuis moet doen vóór het examen:

- Clone de repo.
- Er zijn verschillende mappen met oefeningen, bv. `oefening-1`, `oefening-2`, ...
- Voer in elke map `npm install` uit.

Eindresultaat: Map met meerdere oefeningen in, in elke map met een oefening is een package.json, package-lock.json en node_modules map terug te vinden.

Wat je tijdens het examen doet:

- Download het zipbestand.
- Pak alles van het zipbestand uit.
- Er zijn verschillende mappen met identieke namen terug te vinden, kopieer de inhoud van de mappen over naar de gelijknamige mappen waarin de node_modules al terug te vinden is.

Wat je tijdens het indienen doet:

- Verwijder alle node_modules-mappen.
- Zip de map met alle oefeningen.
- Dien deze nieuwe zip in (de afgewerkte oefeningen, zonder de node_modules-mappen).
