<script setup>
import { ref } from 'vue';
import StatKaart from '@/components/StatKaart.vue';

const selectie = ref(null);

function handleGeselecteerd(label) {
  selectie.value = label;
}
</script>

<template>
  <main>
    <h1>Dashboard</h1>

    <p v-if="selectie" class="melding">Je hebt {{ selectie }} geselecteerd.</p>

    <div class="kaarten">
      <StatKaart
        label="Actieve gebruikers"
        :waarde="1284"
        eenheid="gebruikers"
        @geselecteerd="handleGeselecteerd"
      >
        Gemeten over de afgelopen 30 dagen.
      </StatKaart>

      <StatKaart
        label="Omzet deze maand"
        :waarde="24600"
        eenheid="euro"
        @geselecteerd="handleGeselecteerd"
      >
        Ten opzichte van vorige maand +12%.
      </StatKaart>

      <StatKaart
        label="Openstaande tickets"
        :waarde="37"
        eenheid="tickets"
        @geselecteerd="handleGeselecteerd"
      >
        Waarvan 5 met hoge prioriteit.
      </StatKaart>
    </div>
  </main>
</template>
