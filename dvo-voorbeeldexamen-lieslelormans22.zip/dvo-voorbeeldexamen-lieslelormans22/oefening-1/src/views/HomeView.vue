<script setup>
import ExampleComponent from '@/components/ExampleComponent.vue';
</script>

<template>
  <div class="home">
    <h1>Home</h1>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas voluptate, cumque, quisquam,
      magnam corporis doloremque dicta consequatur deleniti asperiores. Voluptas voluptate, cumque,
      quisquam, magnam corporis doloremque dicta consequatur deleniti asperiores.
    </p>

    <ExampleComponent />
  </div>
</template>
