<template>
  <div class="example">
    <h2>Example</h2>
    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eligendi, placeat.</p>
  </div>
</template>

<style scoped>
.example {
  border: 1px solid #ccc;
  padding: 1rem;
}
</style>
