<script setup>
defineProps({
  label: {
    type: String,
    required: true,
  },
  waarde: {
    type: Number,
    required: true,
  },
  eenheid: {
    type: String,
    default: '',
  },
});

const emit = defineEmits(['geselecteerd']);

function handleKlik(label) {
  emit('geselecteerd', label);
}
</script>

<template>
  <div class="stat-kaart" @click="handleKlik(label)">
    <h2 class="stat-label">{{ label }}</h2>
    <p class="stat-waarde">
      {{ waarde }} <span v-if="eenheid" class="stat-eenheid">{{ eenheid }}</span>
    </p>
    <p><slot /></p>
  </div>
</template>

<style scoped>
.stat-kaart {
  border: 2px solid var(--pxl-zwart);
  border-radius: 0;
  padding: 1.5rem;
  background: var(--pxl-wit);
  cursor: pointer;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.stat-label {
  font-size: 0.85rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--pxl-paars);
}

.stat-waarde {
  font-size: 2rem;
  font-weight: 700;
  color: var(--pxl-zwart);
}

.stat-eenheid {
  font-size: 1rem;
  font-weight: 300;
  color: var(--pxl-goud);
}
</style>
